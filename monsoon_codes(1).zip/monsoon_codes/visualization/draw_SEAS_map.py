# -*- coding: utf-8 -*-
"""
Created on Thu Nov  9 21:13:41 2023

@author: rangu
"""
import numpy as np
from mpl_toolkits.basemap import Basemap, shiftgrid
import cmaps
import matplotlib as mpl
import cmocean
from netCDF4 import Dataset
import matplotlib.pylab as plt

def read_forecast_data():
    # file = 'ecmwf_system51_season1_leading4.nc'
    file = 'ecmwf_system5_leading1.nc'
    nc = Dataset(file)
    return nc


def pick_region(llat, ulat, rlon, llon):
    # file = 'ecmwf_system51_season1_leading4.nc'
    file = 'ecmwf_system5_leading1.nc'
    nc = Dataset(file)
    lats = nc.variables['latitude'][:]; lons = nc.variables['longitude'][:]
    x, y = np.meshgrid(lons, lats)
    xx = x.flatten(); yy = y.flatten()
    nodes_ind = []
    for i in range(len(xx)):
        if llat < yy[i] < ulat and rlon < xx[i] < llon:
            nodes_ind.append(i)
    return nodes_ind


def cal_mean_prate_season1(tprate):
    months = np.arange(396).reshape(33,-1)
    months_ind = []
    for y in range(33):
        temp = months[y][4:10]
        months_ind.append(temp)
    months_ind = np.array(months_ind).flatten()
    months_ind = months_ind[:-2]
    
    ensemble_mean = np.mean(tprate, axis=1)
    mean = np.mean(ensemble_mean[months_ind,:,:], axis=0) * 1000
    return mean


def cal_mean_prate_season2(tprate):
    months = np.arange(396).reshape(33,-1)
    months_ind = []
    for y in range(32):
        temp1 = months[y][10:12]
        temp2 = months[y+1][:4]
        temp = list(temp1)+list(temp2)
        months_ind.append(temp)
    months_ind = np.array(months_ind).flatten()
    months_ind = months_ind[:-2]
    
    ensemble_mean = np.mean(tprate, axis=1)
    mean = np.mean(ensemble_mean[months_ind,:,:], axis=0) * 1000
    return mean


def draw_map(data, nodes):
    lat = data.variables['latitude'][:]; lon = data.variables['longitude'][:]
    prate = data.variables['tprate'][:,:25,:,:]
    prate = cal_mean_prate_season2(prate)
    # vmin = np.min(prate); vmax = np.max(prate)
    vmin = 0.000025; vmax = 0.00015
    
    plt.figure(dpi=400, figsize=(10,10))
    # plt.title('SEAS5: MJJASO (33 years avg, lead 1 month)', fontsize=14)
    plt.title('SEAS5: NDJFMA (32 years avg, lead 1 month)', fontsize=14)
    m = Basemap(projection='cyl',lat_0=0, lon_0=0, resolution='i')
    m.drawcoastlines(linewidth=0.5)
    m.drawcountries(linewidth=0.25)
    m.drawmapboundary(fill_color='#ffffff')
    m.drawmeridians(np.arange(0, 360, 90), labels=[1,0,0,1],size=10,dashes=[2,2],family='Arial')
    m.drawparallels(np.arange(-90, 90.001, 45), labels=[1,0,0,1],size=10,dashes=[2,2],family='Arial')
    
    new_prate, new_lon = shiftgrid(180, prate, lon, start=False)
    xx, yy = np.meshgrid(new_lon, lat)
    xxx, yyy = m(xx, yy)
    
    cmap = cmocean.cm.rain
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    # cb = plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad=0.05, shrink=0.6,
    #                   orientation='horizontal', extend='both')
    # cb.ax.tick_params(labelsize=10)
    # cb.set_label('Precipitation rate '+r'$(kg/m^2/s)$', fontsize=12)
    levels = []
    delta = (vmax-vmin)/50
    for kk in np.arange(vmin, vmax, delta): levels.append(kk) 
    m.contourf(xxx, yyy, new_prate, cmap=cmap, norm=norm, levels=levels, extend='both')
    xxxx = xxx.flatten(); yyyy = yyy.flatten()
    # m.scatter(xxxx[nodes], yyyy[nodes], marker='x', s=100, c='#1e90ff', zorder=2, alpha=.9)
    # return lat, new_lon
    xx2 = xx.flatten(); yy2 = yy.flatten()
    return list(zip(xx2[nodes], yy2[nodes]))


nc = read_forecast_data()
nodes = pick_region(20, 22, 180+76.875, 180+80.625)
nodes_latlon = draw_map(nc, nodes)   