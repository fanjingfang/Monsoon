import numpy as np
import matplotlib.pylab as plt
import matplotlib.colors as mcolors
import matplotlib as mpl
from scipy.interpolate import griddata
import cartopy.crs as ccrs


nodes_file = np.loadtxt('nodes_6242.txt')
lats = nodes_file[:,0]; lons = nodes_file[:,1]
path = './degree_predictor/'


def draw_interpolation_cartopy(data, vmin, vmax, predictor, sig):
    fig, ax = plt.subplots(dpi=300, figsize=(8,8), 
                           subplot_kw={'projection': ccrs.Hammer(central_longitude=-180)})
    plt.title('CI', fontsize=22)
    ax.coastlines(linewidth=.5)
    gl = ax.gridlines(draw_labels=False, xlocs=np.arange(-180, 180+1, 90), ylocs=np.arange(-90, 90+1, 45),
                       linewidth=.5, linestyle='--', color='k')
    ax.text(2, -45, '45°S', transform=ccrs.PlateCarree(), va='top', ha='right', fontsize=16)
    ax.text(2, 0, '0°', transform=ccrs.PlateCarree(), va='center', ha='right', fontsize=16)
    ax.text(2, 45, '45°N', transform=ccrs.PlateCarree(), va='bottom', ha='right', fontsize=16)
    # gl.top_labels = False
    # gl.right_labels = False
    # lon_formatter = cticker.LongitudeFormatter()
    # lat_formatter = cticker.LatitudeFormatter()
    
    lat = np.linspace(-90, 90, 94)
    lon = np.linspace(0, 360, 192)
    
    levels = []
    delta = (vmax-vmin)/100
    for kk in np.arange(vmin, vmax, delta): levels.append(kk)
    
    norm = mcolors.TwoSlopeNorm(vmin=vmin, vmax=vmax, vcenter=np.percentile(data, 50))
    cmap = 'PuBuGn'
    # cmap = cmaps.cmocean_ice_r
    
    c11 = ax.contourf(lon, lat, data, zorder=0, extend='both',
                      transform=ccrs.PlateCarree(), cmap=cmap, norm=norm, levels=levels)
    
    tick1 = round(np.percentile(data, 3), 1) ; tick2 = round(np.percentile(data, 75), 1);
    tick3 = round(np.percentile(data, 95), 1)
    ticks = [tick1, tick2, tick3]
    cb = plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad=0.05, shrink=.4,
                      orientation='vertical', extend='both', ticks=ticks, ax=ax)
    cb.ax.tick_params(labelsize=18)
    
    
    plt.scatter(x=lons[predictor], y=lats[predictor], zorder=1,
                color="r",
                s=80,
                alpha=1,
                transform=ccrs.PlateCarree()) ## Important
    
    xx, yy = np.meshgrid(lon, lat)
    xx = xx.flatten(); yy = yy.flatten()
    plt.scatter(x=lons[sig], y=lats[sig], marker='|', s=12, c='w', alpha=.6, 
                transform=ccrs.PlateCarree())
    
    # x1, y1 = 307,-1; width, height = 6,2 # EAR
    # x1, y1 = 108,18; width, height = 3,2 # HI
    # x1, y1 = 31,6; width, height = 3,8 # SEA
    x1, y1 = 76,20; width, height = 5,2 # CI
    
    ax.add_patch(plt.Rectangle((x1,y1),width,height, 
                  fill=True, facecolor='none', edgecolor='b', hatch='////', 
                  linewidth=2, zorder=3, transform=ccrs.PlateCarree()))
    plt.show()


def read_degree(year, predictor, deg_ind):
    degree = np.loadtxt(path+'deg_ave_{}_{}.dat'.format(year, predictor))[:,deg_ind]
    return degree


def draw_degree_pdf(data):
    plt.figure(dpi=300, figsize=(10,2))
    plt.hist(data, bins=200, edgecolor='k', facecolor='r',
             density=True)


def interpolation(data):
    target_lat = np.linspace(-90, 90, num=94)
    target_lon = np.linspace(0, 360 ,num=192)
    target_lon, target_lat = np.meshgrid(target_lon, target_lat)
    target_data = griddata((lons, lats), data, (target_lon, target_lat), method='nearest')
    return target_data
    

def draw_degree(predictor, deg_ind):
    # vmin = 100000; vmax = -1000000
    # for year in range(1949, 2022):
    #     data = read_degree(year, predictor, deg_ind)
    #     vmax = max(np.max(data), vmax)
    #     vmin = min(np.min(data), vmin)
    # print(vmin, vmax)
    data = []
    for year in range(1950, 2022):
        data_temp = read_degree(year, predictor, deg_ind)
        data.append(data_temp)
        # draw(data, vmin, vmax, predictor)
        # plt.show()
    data = np.abs(np.mean(np.array(data), axis=0))
    threshold = np.percentile(data, 95)
    sig = np.where(data>threshold)[0]
    print(len(sig), sig)
    # draw_degree_pdf(data)
    # data = np.mean(np.array(data), axis=0)
    data = interpolation(data)
   
    # vmin = np.min(data)
    # vmax = np.max(data)
    vmin = np.percentile(data, 2.5)
    vmax = np.percentile(data, 97.5)
    print(vmin, vmax)
    # draw(data, vmin, vmax, predictor, [])
    # data2 = draw_interpolation(data, vmin, vmax, predictor, sig)
    draw_interpolation_cartopy(data, vmin, vmax, predictor, sig)
    return np.array(data)