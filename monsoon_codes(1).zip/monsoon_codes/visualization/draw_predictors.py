import numpy as np
import matplotlib.pylab as plt
from netCDF4 import Dataset
path = './'
Nodes_6242 = np.loadtxt('nodes_6242.txt')
lats_6242 = Nodes_6242[:,0]; lons_6242 = Nodes_6242[:,1]


def draw_connection(nodes1, nodes2):
    prate = np.loadtxt('prate_1.dat')
    prate = np.mean(prate[:,40:], axis=1)
    # vmin = np.min(prate); vmax = np.max(prate)
    vmin = 0.000025; vmax = 0.00015
    prate = prate.reshape(94,192)
    
    plt.figure(dpi=400, figsize=(10,10))
    # plt.title('May to Oct.', fontsize=14)
    # plt.title('NCEP: NDJFMA (33 years avg)', fontsize=14)
    plt.title('NCEP: MJJASO (33 years avg)', fontsize=14)
    from mpl_toolkits.basemap import Basemap, shiftgrid
    import cmaps
    import matplotlib as mpl
    import cmocean
    m = Basemap(projection='cyl',lat_0=-90, lon_0=0, resolution='i')
    # m.etopo(scale=0.2)
    # m.shadedrelief(scale=0.2)
    # m = Basemap(llcrnrlon=-90, llcrnrlat=-30, urcrnrlon=0, urcrnrlat=15, projection='lcc', lat_1=-45, lat_2=0, lon_0=-45) 
    m.drawcoastlines(linewidth=0.5)
    m.drawcountries(linewidth=0.25)
    m.drawmapboundary(fill_color='#ffffff')
    # m.fillcontinents(color='#c0c0c0',lake_color='#ffffff')
    m.drawmeridians(np.arange(0, 360, 90), labels=[1,0,0,1],size=10,dashes=[2,2],family='Arial')
    m.drawparallels(np.arange(-90, 90.001, 45), labels=[1,0,0,1],size=10,dashes=[2,2],family='Arial')
    
    start_lat = lats_6242[nodes1]; start_lon = lons_6242[nodes1]
    x1, y1 = m(lons_6242, lats_6242)
    
    nc = Dataset(path+'prate.sfc.mon.mean.nc')
    lat2 = nc.variables['lat'][:]; lon2 = nc.variables['lon'][:]; lon2[-1] = 360
    x2, y2 = np.meshgrid(lon2, lat2)
    xx2 = x2.flatten(); yy2 = y2.flatten()
    end_lat = yy2[nodes2]; end_lon = xx2[nodes2]
    xxx2, yyy2 = m(xx2, yy2)
    xxxx2 = xxx2.flatten(); yyyy2 = yyy2.flatten()
    
    new_prate, new_lon = shiftgrid(180, prate, lon2, start=False)
    xx, yy = np.meshgrid(new_lon, lat2)
    xxx2, yyy2 = m(xx, yy)

    # m.scatter(x1[nodes1], y1[nodes1], marker='o', s=75, c='#ff1493', zorder=2, alpha=.8)
    # m.scatter(xxxx2[nodes2], yyyy2[nodes2], marker='s', s=30, c='#1e90ff', zorder=2, alpha=.9)

    # cmap = cmaps.precip4_11lev
    cmap = cmocean.cm.rain
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    # norm = mcolors.DivergingNorm(vmin=vmin, vmax=vmax, vcenter=0)
    # cb = m.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad="10%", shrink=0.05,
    #                 location='bottom', extend='both')
    # cb = plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad=0.05, shrink=0.6,
    #                   orientation='horizontal', extend='both')
    # cb.ax.tick_params(labelsize=10)
    # cb.set_label('Precipitation rate '+r'$(kg/m^2/s)$', fontsize=12)
    levels = []
    delta = (vmax-vmin)/25
    for kk in np.arange(vmin, vmax, delta): levels.append(kk) 
    # m.contourf(xxx2, yyy2, new_prate, cmap=cmap, norm=norm, levels=levels, extend='both')
    m.pcolormesh(xxx2, yyy2, new_prate, cmap=cmap, norm=norm, shading='gouraud')
    
    # k = -1
    # for i in nodes1:
    #     k += 1
    #     if np.abs(start_lon[k]-end_lon[k])<2 and np.abs(start_lat[k]-end_lat[k])<2:
    #         m.scatter(x1[i], y1[i], marker='o', s=50, c='#ff00ff', zorder=2, alpha=.8)
    #     else:    
    #         m.drawgreatcircle(start_lon[k], start_lat[k], end_lon[k], end_lat[k],
    #                           linewidth=.5, color='k', alpha=.9)
    return np.array([start_lat, start_lon]), np.array([end_lat, end_lon])


def draw_colorbar(vmin, vmax, cmap):
    import matplotlib.cm as cm
    from matplotlib.ticker import ScalarFormatter
    fig, ax = plt.subplots(figsize=(.25,10), dpi=800)
    norm = plt.Normalize(vmin=vmin, vmax=vmax)
    scalar_map = cm.ScalarMappable(norm=norm, cmap=cmap)
    
    formatter = ScalarFormatter(useMathText=True)
    formatter.set_scientific(True)
    formatter.set_powerlimits((-4, -4))
    
    cbar = plt.colorbar(scalar_map, cax=ax, pad=0.05, shrink=0.3,
                        orientation='vertical', extend='both',
                        format=formatter)
    cbar.ax.tick_params(labelsize=20)
    cbar.set_label('Precipitation rate '+r'$(kg/m^2/s)$', fontsize=24)
    plt.rc('font', size=20)
    plt.show()
    
    
def draw_connection2(nodes1, nodes2, target_regions):
    prate = np.loadtxt('./prate_2.dat')
    prate = np.mean(prate[:,40:], axis=1)
    prate = prate.reshape(94,192)
    
    fig, ax = plt.subplots(dpi=400, figsize=(8,8))
    
    from mpl_toolkits.basemap import Basemap, shiftgrid
    
    start_lat = lats_6242[nodes1]; start_lon = lons_6242[nodes1]
    nc = Dataset('./prate.sfc.mon.mean.nc')
    lat2 = nc.variables['lat'][:]; lon2 = nc.variables['lon'][:]
    x2, y2 = np.meshgrid(lon2, lat2)
    xx2 = x2.flatten(); yy2 = y2.flatten()
    end_lat = yy2[nodes2]; end_lon = xx2[nodes2]
    print(end_lat, end_lon)
    
    # start_lat_mean = np.mean(start_lat); start_lon_mean = np.mean(start_lon)
    # end_lat_mean = np.mean(end_lat); end_lon_mean = np.mean(end_lon)
    # lat_0 = (start_lat_mean + end_lat_mean)/2
    # lon_0 = (start_lon_mean + end_lon_mean)/2
    

    # m = Basemap(llcrnrlon=-152.5, llcrnrlat=-35, urcrnrlon=-42.5, urcrnrlat=20,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h')
    # target_regions = 'EAR'
    
    # m = Basemap(llcrnrlon=-80, llcrnrlat=-20, urcrnrlon=-40, urcrnrlat=10,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h')
    # target_regions = 'EAR'    
    
    
    # m = Basemap(llcrnrlon=70, llcrnrlat=-10, urcrnrlon=135, urcrnrlat=55,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='f') # Map of Central India
    # m = Basemap(llcrnrlon=74, llcrnrlat=5, urcrnrlon=134, urcrnrlat=35,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h', ax=ax) # Map of Central India
    # target_regions = 'CI'
    
    # m = Basemap(llcrnrlon=-10, llcrnrlat=-20, urcrnrlon=55, urcrnrlat=45,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h') # Map of Eastern Sahel
    # m = Basemap(llcrnrlon=5, llcrnrlat=0, urcrnrlon=40, urcrnrlat=17.5,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h') # Map of Eastern Sahel
    # target_regions = 'SEA'
    
    # m = Basemap(llcrnrlon=80, llcrnrlat=-15, urcrnrlon=145, urcrnrlat=50,
    #             projection='cyl', lon_0=-180, lat_0=0, resolution='h') # Map of Hainan
    m = Basemap(llcrnrlon=100, llcrnrlat=10, urcrnrlon=125, urcrnrlat=22.5,
                projection='cyl', lon_0=-180, lat_0=0, resolution='i') # Map of Hainan
    target_regions = 'HI'
    
    plt.title(target_regions, fontsize=24)
    m.drawcoastlines(linewidth=1)
    # m.drawcountries(linewidth=.5)
    m.drawparallels(np.arange(-90.,120.,20.),labels=[True,False,False,False],fontsize=18,linewidth=0)
    m.drawmeridians(np.arange(0.,360.,30),labels=[False,False,False,True],fontsize=18,linewidth=0)
    
    x1, y1 = m(lons_6242, lats_6242)
    xxx2, yyy2 = m(xx2, yy2)
    xxxx2 = xxx2.flatten(); yyyy2 = yyy2.flatten()
    new_prate, new_lon = shiftgrid(180, prate, lon2, start=False)
    xx, yy = np.meshgrid(new_lon, lat2)
    xxx2, yyy2 = m(xx, yy)
    # xx, yy = np.meshgrid(lon2, lat2)
    # xxx2, yyy2 = m(xx, yy)

    m.scatter(x1[nodes1], y1[nodes1], marker='o', s=600, c='r', zorder=2, alpha=1)
    # m.scatter(xxxx2[nodes2], yyyy2[nodes2], marker='s', s=200, c='#1e90ff', zorder=2, alpha=.75)
    
    # cmap = cmocean.cm.rain
    # cmap = cmaps.YIOrRd
    # cmap = 'viridis'
    # norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    # norm = mcolors.DivergingNorm(vmin=vmin, vmax=vmax, vcenter=0)
    # cb = m.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad="10%", shrink=0.05,
    #                 location='bottom', extend='both')
    # cb = plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), pad=0.05, shrink=0.8,
    #                   orientation='horizontal', extend='both')
    # cb.ax.tick_params(labelsize=10)
    # cb.set_label('Precipitation rate '+r'$(kg/m^2/s)$', fontsize=14)
    # levels = []
    # delta = (vmax-vmin)/50
    # for kk in np.arange(vmin, vmax, delta): levels.append(kk) 
    # m.contourf(xxx2, yyy2, new_prate, cmap='viridis', norm=norm, levels=levels, extend='both')
    
    lon_min = min(xxxx2[nodes2])-.94; lat_min = min(yyyy2[nodes2])-.95*2
    lon_max = max(xxxx2[nodes2])+.94; lat_max = max(yyyy2[nodes2])+.95*2
    # lon_min = min(xxxx2[nodes2]); lat_min = min(yyyy2[nodes2])
    # lon_max = max(xxxx2[nodes2]); lat_max = max(yyyy2[nodes2])
    # lon_min = 15; lat_min = 40
    # lon_max = 25; lat_max = 60
    xxxxx1, yyyyy1 = m(lon_min, lat_min)
    xxxxx2, yyyyy2 = m(lon_max, lat_max)
    rect = plt.Rectangle((xxxxx1, yyyyy1), xxxxx2-xxxxx1, yyyyy2-yyyyy1, 
                         fill=True, facecolor='none', edgecolor='b', hatch='////', 
                         linewidth=2, zorder=3)
    ax.add_patch(rect)
    # k = -1
    # for i in nodes1:
    #     k += 1
    #     if np.abs(start_lon[k]-end_lon[k])<2 and np.abs(start_lat[k]-end_lat[k])<2:
    #         m.scatter(x1[i], y1[i], marker='o', s=50, c='#ff00ff', zorder=2, alpha=.8)
    #     else:    
    #         m.drawgreatcircle(start_lon[k]-360, start_lat[k], end_lon[k]-360, end_lat[k],
    #                           linewidth=2, color='k', alpha=.5)
    plt.show()
    # draw_colorbar(vmin, vmax, cmap)


degrees=['div','out','in','div_ave','out_ave','in_ave']
weights=['Wpos','Cmax','Wneg','Cmin','Wabs','Cabs','aWabs','aCabs']
def run():
    # target = [6953,6954,6955,6761,6762,6763]
    # predictor = [1548,1548,1548,1548,1548,1548]
    # predictor = [1549,1549,1549,1549,1549,1549]
    # regions = 'Central India'; deg_ind = 4; weight_ind = 0; season = 1
    # # optimal_L = 32 # quadratic
    # optimal_L = 8
    # predictor_name = r'$k^{out+}_{1548}$'
    # std = cal_seasonal_std(4, 10)
    
    # target = [7697,7698,7889,7890,8081,8082,8273,8274]
    # # predictor = [2447,2447,2447,2447,2447,2447,2447,2447]
    # predictor = [2446,2446,2446,2446,2446,2446,2446,2446]
    # regions = 'Eastern Sahel regions'; deg_ind = 4; weight_ind = 2; season = 1
    # # optimal_L = 11 # quadratic
    # optimal_L = 5
    # predictor_name = r'$-1\times k^{in-}_{2447}$'
    # std = cal_seasonal_std(4, 10)
    
    target = [8996,8997,9188,9189,9191]
    predictor = [4279,4279,4279,4279,4279]
    # predictor = [4144,4144,4144,4144,4144]
    # predictor = [3274,3274,3274,3274,3274]
    # predictor = [3273,3274,3275,3276,3277]
    # predictor = [3951,3951,3951,3951,3951]
    regions = 'Eastern Amazon rainforest'; deg_ind = 4; weight_ind = 2; season = 2
    # # optimal_L = 12 # quadratic
    # optimal_L = 37
    # predictor_name = r'$k^{out-}_{4279}$'
    # std = cal_seasonal_std(10, 16)
    
    # target = [6970,6971,7162,7163]
    # predictor = [2500,2500,2500,2500]
    # regions = 'Hainan Island'; deg_ind = 4; weight_ind = 2; season = 1
    # # optimal_L = 22 # quadratic
    # optimal_L = 40
    # predictor_name = r'$k^{out-}_{2500}$'
    # std = cal_seasonal_std(4, 10)
    
    # target = [6953,6954,6955,6761,6762,6763,6971,6971,6971,6971,7697,7698,7889,7890]
    # predictor = [1548,1548,1548,1548,1548,1548,2310,2310,2310,2310,2446,2446,2446,2446]
    
    
    pred_loc, tart_loc = draw_connection(predictor, target)
    draw_connection2(predictor, target, regions)