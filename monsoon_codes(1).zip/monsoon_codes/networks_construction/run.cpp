#include "calculation.h"
#include <iostream>
#include <math.h>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <cstdlib>
#include <sstream>
#include <fstream>
#include <cmath>
#include <string>
#include <mpi.h>

using namespace std;

int main(int argc, char **argv){
    int rank;
    int size;

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
    for(int i=rank; i<73; i+=size){
        read_deg(i);
        for(int j=0; j<2; j++){
            read_prate(j);
            calculation1(i, j);
        }
        //test(i, rank, size);
    }
    MPI_Finalize();
    
    return 0;
}

void test(int i, int rank, int size){
    ofstream fout1,fout2;
    stringstream ss, ss2;
    string stagestr, stagestr2;
    
    ss.clear();
    ss << rank;
    ss >> stagestr;
    
    ss2.clear();
    ss2 << i;
    ss2 >> stagestr2;

    string a="test_"; // output filename
    string b="_.txt";
    string filename = out_file + a + stagestr + "_" + stagestr2 + b;

    fout1.open(filename.c_str());
    fout1 << i << "," << rank << "," << size << "\n";
    fout1.close();
}

void read_deg(int deg_ind){
    stringstream ss_ind;
    string ind_str;
    ss_ind.clear();
    ss_ind << deg_ind+1;
    ss_ind >> ind_str;

    string filename;
    filename = "./_"+ind_str+".dat";
    ifstream filetemp(filename);

    for(int i=0; i<Nodes1; i++){
        for(int j=0; j<Timelength; j++){
            filetemp >> deg[i][j];
        }
    }
}


void read_prate(int rank){
    stringstream s_rank;
    string month;
    s_rank.clear();
    s_rank << rank+1;
    s_rank >> month;

    string filename;
    filename = "./_"+month+".dat";
    ifstream filetemp(filename);

    for(int i=0; i<Nodes2; i++){
        for(int j=0; j<Timelength; j++){
            filetemp >> prate[i][j];
        }
    }
}


void calculation1(int rank, int month){
    
    double ccf;

    ofstream fout;
    stringstream ss;
    stringstream ss2;

    string deg_str;
    string month1;

    ss.clear();
    ss2.clear();
    ss << rank;
    ss2 << month+1;
    ss >> deg_str;
    ss2 >> month1;

    string b = ".dat";
    string c = "rvalue_deg";
    string filename = out_file + c + deg_str + "_month" + month1 + b;
    fout.open(filename.c_str());

    int st = 0;
    int edge = -1;
    for(int node2=0; node2<Nodes2; node2++){
        int i=node2;
        double r_max = 0;
        int node_max = -1;
        for(int node1=0; node1<Nodes1; node1++){
            int j=node1;
            edge++ ;
            ccf = cal_ccf(j, i, st, st, stagelength);
            if (fabs(ccf) > fabs(r_max)){
                r_max = ccf;
                node_max = j;
            }
        }
        fout << i << " " << node_max << " " << r_max << "\n";
    }
    fout.close();
}