import numpy as np
N = 6242
links = np.arange(N*N).reshape(N,N)
linkx = []; linkxn = []
for i in range(N-1):
    for j in range(i+1,N):
        linkx.append(links[i,j])
        linkxn.append(links[j,i])

def read_data(year):
    
    #data = np.loadtxt('C:/Users/Orange/Desktop/hainan_0206/networks/network_{}_t2m.dat'.format(year))
    data = np.loadtxt('/public3/home/sc52351/ranguanghao/hainan0206/data/results/network_{}_t2m.dat'.format(year))
    
    return data

def cal_degree(year):
    
    #outfile1=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_outd.dat'.format(year),'w')
    outfile1 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_outd.dat'.format(year),'w')
    #outfile2=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_ind.dat'.format(year),'w')
    outfile2 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_ind.dat'.format(year),'w')
    #outfile3=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_divd.dat'.format(year),'w')
    outfile3 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_divd.dat'.format(year),'w')
    
    #rd_st = time.time()
    data = read_data(year)
    #rd_ed = time.time()
    #print('Reading data{} costs {}s'.format(year, rd_ed-rd_st))
    
    wpx = data[:,2]; wnx = data[:,3]
    tpx = data[:,4]; tnx = data[:,5]; tax = data[:,6]
    cpx = data[:,8]; cnx = data[:,9]

    wpmatrix = np.zeros(N*N); wnmatrix = np.zeros_like(wpmatrix); wamatrix = np.zeros_like(wpmatrix); waamatrix = np.zeros_like(wpmatrix)
    cpmatrix = np.zeros_like(wpmatrix); cnmatrix = np.zeros_like(wpmatrix); camatrix = np.zeros_like(wpmatrix); caamatrix = np.zeros_like(wpmatrix)
    tpmatrix = np.zeros_like(wpmatrix); tnmatrix = np.zeros_like(wpmatrix); tamatrix = np.zeros_like(wpmatrix)
    
    cax=[]; wax=[]; tax=[]; caax=[]; waax=[]
    for i in range(len(cpx)):
        a=abs(cpx[i])
        b=abs(cnx[i])
        a1=abs(wpx[i])
        b1=abs(wnx[i])
        
        if(a>=b):
            c=cpx[i]
            d=a
            c1=wpx[i]
            d1=a1
            e=tpx[i]
        else:
            c=cnx[i]
            d=a
            c1=wnx[i]
            d1=b1
            e=tnx[i]
        cax.append(c)
        wax.append(c1)
        tax.append(e)
        caax.append(d)
        waax.append(d1)
        
    wpmatrix[linkx]=wpx; wnmatrix[linkx]=wnx; wamatrix[linkx]=wax; waamatrix[linkx]=waax
    cpmatrix[linkx]=cpx; cnmatrix[linkx]=cnx; camatrix[linkx]=cax; caamatrix[linkx]=caax
    tpmatrix[linkx]=tpx; tnmatrix[linkx]=tnx; tamatrix[linkx]=tax
    wpmatrix[linkxn]=wpx; wnmatrix[linkxn]=wnx; wamatrix[linkxn]=wax; waamatrix[linkxn]=waax
    cpmatrix[linkxn]=cpx; cnmatrix[linkxn]=cnx; camatrix[linkxn]=cax; caamatrix[linkxn]=caax
    tpmatrix[linkxn]=-np.array(tpx); tnmatrix[linkxn]=-np.array(tnx); tamatrix[linkxn]=-np.array(tax)

    wpmatrix=np.reshape(wpmatrix,(N,N))
    wnmatrix=np.reshape(wnmatrix,(N,N))
    wamatrix=np.reshape(wamatrix,(N,N))
    waamatrix=np.reshape(waamatrix,(N,N))
    cpmatrix=np.reshape(cpmatrix,(N,N))
    cnmatrix=np.reshape(cnmatrix,(N,N))
    camatrix=np.reshape(camatrix,(N,N))
    caamatrix=np.reshape(caamatrix,(N,N))
    tpmatrix=np.reshape(tpmatrix,(N,N))
    tnmatrix=np.reshape(tnmatrix,(N,N))
    tamatrix=np.reshape(tamatrix,(N,N))
    
    for k in range(N):
        outpx=np.where(np.array(tpmatrix[k,:])<=0)[0]
        inpx=np.where(np.array(tpmatrix[k,:])>=0)[0]
        outnx=np.where(np.array(tnmatrix[k,:])<=0)[0]
        innx=np.where(np.array(tnmatrix[k,:])>=0)[0]        
        outax=np.where(np.array(tamatrix[k,:])<=0)[0]
        inax=np.where(np.array(tamatrix[k,:])>=0)[0]   
        outwpx=sum(wpmatrix[k,outpx])
        outcpx=sum(cpmatrix[k,outpx])
        outwnx=sum(wnmatrix[k,outnx])
        outcnx=sum(cnmatrix[k,outnx])
        outwax=sum(wamatrix[k,outax])
        outwaax=sum(waamatrix[k,outax])
        outcax=sum(camatrix[k,outax])
        outcaax=sum(caamatrix[k,outax])
        inwpx=sum(wpmatrix[k,inpx])
        incpx=sum(cpmatrix[k,inpx])
        inwnx=sum(wnmatrix[k,innx])
        incnx=sum(cnmatrix[k,innx])
        inwax=sum(wamatrix[k,inax])
        inwaax=sum(waamatrix[k,inax])
        incax=sum(camatrix[k,inax])  
        incaax=sum(caamatrix[k,inax])
        divwpx=outwpx-inwpx
        divcpx=outcpx-incpx
        divwnx=outwnx-inwnx
        divcnx=outcnx-incnx
        divwax=outwax-inwax
        divwaax=outwaax-inwaax
        divcax=outcax-incax
        divcaax=outcaax-incaax
        outfile1.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(outwpx,outcpx,outwnx,outcnx,outwax,outcax,outwaax,outcaax))
        outfile2.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(inwpx,incpx,inwnx,incnx,inwax,incax,inwaax,incaax))
        outfile3.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(divwpx,divcpx,divwnx,divcnx,divwax,divcax,divwaax,divcaax))
        
    outfile1.close()
    outfile2.close()
    outfile3.close()
    
def cal_degree_avg(year):
    
    #outfile1=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_outdavg.dat'.format(year),'w')
    #outfile2=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_indavg.dat'.format(year),'w')
    #outfile3=open('C:/Users/Orange/Desktop/hainan_0206/degree/{}_divdavg.dat'.format(year),'w')
    
    outfile1 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_outdavg.dat'.format(year),'w')
    outfile2 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_indavg.dat'.format(year),'w')
    outfile3 = open('/public3/home/sc52351/ranguanghao/hainan0206/data/results/degree/{}_divdavg.dat'.format(year),'w')
    
    #rd_st = time.time()
    data = read_data(year)
    #rd_ed = time.time()
    #print('Reading data{} costs {}s'.format(year, rd_ed-rd_st))
    
    wpx = data[:,2]; wnx = data[:,3]
    tpx = data[:,4]; tnx = data[:,5]; tax = data[:,6]
    cpx = data[:,8]; cnx = data[:,9]

    wpmatrix = np.zeros(N*N); wnmatrix = np.zeros_like(wpmatrix); wamatrix = np.zeros_like(wpmatrix); waamatrix = np.zeros_like(wpmatrix)
    cpmatrix = np.zeros_like(wpmatrix); cnmatrix = np.zeros_like(wpmatrix); camatrix = np.zeros_like(wpmatrix); caamatrix = np.zeros_like(wpmatrix)
    tpmatrix = np.zeros_like(wpmatrix); tnmatrix = np.zeros_like(wpmatrix); tamatrix = np.zeros_like(wpmatrix)
    
    cax=[]; wax=[]; tax=[]; caax=[]; waax=[]
    for i in range(len(cpx)):
        a=abs(cpx[i])
        b=abs(cnx[i])
        a1=abs(wpx[i])
        b1=abs(wnx[i])
        
        if(a>=b):
            c=cpx[i]
            d=a
            c1=wpx[i]
            d1=a1
            e=tpx[i]
        else:
            c=cnx[i]
            d=a
            c1=wnx[i]
            d1=b1
            e=tnx[i]
        cax.append(c)
        wax.append(c1)
        tax.append(e)
        caax.append(d)
        waax.append(d1)
        
    wpmatrix[linkx]=wpx; wnmatrix[linkx]=wnx; wamatrix[linkx]=wax; waamatrix[linkx]=waax
    cpmatrix[linkx]=cpx; cnmatrix[linkx]=cnx; camatrix[linkx]=cax; caamatrix[linkx]=caax
    tpmatrix[linkx]=tpx; tnmatrix[linkx]=tnx; tamatrix[linkx]=tax
    wpmatrix[linkxn]=wpx; wnmatrix[linkxn]=wnx; wamatrix[linkxn]=wax; waamatrix[linkxn]=waax
    cpmatrix[linkxn]=cpx; cnmatrix[linkxn]=cnx; camatrix[linkxn]=cax; caamatrix[linkxn]=caax
    tpmatrix[linkxn]=-np.array(tpx); tnmatrix[linkxn]=-np.array(tnx); tamatrix[linkxn]=-np.array(tax)

    wpmatrix=np.reshape(wpmatrix,(N,N))
    wnmatrix=np.reshape(wnmatrix,(N,N))
    wamatrix=np.reshape(wamatrix,(N,N))
    waamatrix=np.reshape(waamatrix,(N,N))
    cpmatrix=np.reshape(cpmatrix,(N,N))
    cnmatrix=np.reshape(cnmatrix,(N,N))
    camatrix=np.reshape(camatrix,(N,N))
    caamatrix=np.reshape(caamatrix,(N,N))
    tpmatrix=np.reshape(tpmatrix,(N,N))
    tnmatrix=np.reshape(tnmatrix,(N,N))
    tamatrix=np.reshape(tamatrix,(N,N))
    
    for k in range(N):
        outpx=np.where(np.array(tpmatrix[k,:])<=0)[0]
        inpx=np.where(np.array(tpmatrix[k,:])>=0)[0]
        outnx=np.where(np.array(tnmatrix[k,:])<=0)[0]
        innx=np.where(np.array(tnmatrix[k,:])>=0)[0]        
        outax=np.where(np.array(tamatrix[k,:])<=0)[0]
        inax=np.where(np.array(tamatrix[k,:])>=0)[0]   
        outwpx=np.mean(wpmatrix[k,outpx])
        outcpx=np.mean(cpmatrix[k,outpx])
        outwnx=np.mean(wnmatrix[k,outnx])
        outcnx=np.mean(cnmatrix[k,outnx])
        outwax=np.mean(wamatrix[k,outax])
        outwaax=np.mean(waamatrix[k,outax])
        outcax=np.mean(camatrix[k,outax])
        outcaax=np.mean(caamatrix[k,outax])
        inwpx=np.mean(wpmatrix[k,inpx])
        incpx=np.mean(cpmatrix[k,inpx])
        inwnx=np.mean(wnmatrix[k,innx])
        incnx=np.mean(cnmatrix[k,innx])
        inwax=np.mean(wamatrix[k,inax])
        inwaax=np.mean(waamatrix[k,inax])
        incax=np.mean(camatrix[k,inax])
        incaax=np.mean(caamatrix[k,inax])
        divwpx=outwpx-inwpx
        divcpx=outcpx-incpx
        divwnx=outwnx-inwnx
        divcnx=outcnx-incnx
        divwax=outwax-inwax
        divwaax=outwaax-inwaax
        divcax=outcax-incax
        divcaax=outcaax-incaax
        outfile1.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(outwpx,outcpx,outwnx,outcnx,outwax,outcax,outwaax,outcaax))
        outfile2.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(inwpx,incpx,inwnx,incnx,inwax,incax,inwaax,incaax))
        outfile3.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(divwpx,divcpx,divwnx,divcnx,divwax,divcax,divwaax,divcaax))
        
    outfile1.close()
    outfile2.close()
    outfile3.close()

for i in range(1949, 2022):
    cal_degree_avg(i)
