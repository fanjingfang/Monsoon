#ifndef CALCULATION
#define CALCULATION

#include<iostream>
#include<fstream>
#include<cmath>
#include<string>

using namespace std;

string out_file = "./";

int const Nodes1 = 6242;
int const Nodes2 = 192*94;
int const Edges = Nodes1*Nodes2;
int const taumax = 0;
int const Timelength = 33;
int const stagelength = 33;
double deg[Nodes1][Timelength];
double prate[Nodes2][Timelength];

void read_deg(int rank);
void read_prate(int rank);
void calculation1(int rank, int month);
void test(int i, int rank, int size);

double cal_mean(double ccfs[], int st, int ed){
    double k=0; double sum=0;
    for(int i=st; i<=ed; i++){
        sum += ccfs[i];
        k++;
    }
    return sum/k;
}

double cal_std(double ccfs[], int st, int ed, double meanccf){
    double sum=0; double k=0;
    for(int i=st; i<=ed; i++){
        sum += (ccfs[i]-meanccf)*(ccfs[i]-meanccf);
        k++;
    }
    sum = sqrt((1/(k-1))*sum);
    return sum;
}

double cal_ccf(int node1, int node2, int st1, int st2, int length){
    double r;
    double s1=0;
    double s2=0;
    double s3=0;
    double s4=0;
    double s5=0;
    for(int t=0; t<length; t++){
        s1 += deg[node1][st1+t]*prate[node2][st2+t];
        s2 += deg[node1][st1+t];
        s3 += prate[node2][st2+t];
        s4 += deg[node1][st1+t]*deg[node1][st1+t];
        s5 += prate[node2][st2+t]*prate[node2][st2+t];
    }
    r = ((double)length*s1-s2*s3)/(sqrt((double)length*s4-s2*s2)*sqrt((double)length*s5-s3*s3));
    return r;
}

#endif