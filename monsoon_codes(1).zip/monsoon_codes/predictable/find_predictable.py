import numpy as np
from netCDF4 import Dataset
path = './'

#------------------------------------------------------------------------------
def read_deg_data(year):
    path = './'
    
    data1 = np.loadtxt(path+'{}_divd.dat'.format(year))
    data2 = np.loadtxt(path+'{}_outd.dat'.format(year))
    data3 = np.loadtxt(path+'{}_ind.dat'.format(year))
    data4 = np.loadtxt(path+'{}_divdavg.dat'.format(year))
    data5 = np.loadtxt(path+'{}_outdavg.dat'.format(year))
    data6 = np.loadtxt(path+'{}_indavg.dat'.format(year))
    
    datax = [data1, data2, data3, data4, data5, data6]
    return datax


def merge_data():
    temp1 = np.zeros([0,8], dtype=float)
    temp2 = np.zeros_like(temp1)
    temp3 = np.zeros_like(temp1)
    temp4 = np.zeros_like(temp1)
    temp5 = np.zeros_like(temp1)
    temp6 = np.zeros_like(temp1)
    
    for i in range(1949, 2022):
        datax = read_deg_data(i)
        print(i)
        temp1 = np.vstack((temp1, datax[0]))
        temp2 = np.vstack((temp2, datax[1]))
        temp3 = np.vstack((temp3, datax[2]))
        temp4 = np.vstack((temp4, datax[3]))
        temp5 = np.vstack((temp5, datax[4]))
        temp6 = np.vstack((temp6, datax[5]))
    
    dataxx = [temp1, temp2, temp3, temp4, temp5, temp6]
    return dataxx


def read_deg_by_nodes(data, nodes_ind, deg_ind, weight_ind):
    deg_temp = data[deg_ind][:, weight_ind]
    deg = np.reshape(deg_temp, (73, 6242))
    nodes_deg = deg[:, nodes_ind]
    return nodes_deg

#------------------------------------------------------------------------------
def read_prate(month_ind):
    path = './'
    prate = np.loadtxt(path+'prate_{}.dat'.format(month_ind))
    return prate

#------------------------------------------------------------------------------
degrees=['div','out','in','div_ave','out_ave','in_ave']
weights=['Wpos','Cmax','Wneg','Cmin','Wabs','Cabs','aWabs','aCabs']

def read_rvalues(N_years, month_ind):
    r = []; nodes = []
    for deg in range(48):
        data = np.loadtxt(path+'find_predictable/results/{}years/rvalue_deg{}_month{}.dat'
                          .format(N_years, deg, month_ind))
        r_temp = data[:,2]
        nodes_temp = data[:,1]
        r.append(r_temp)
        nodes.append(nodes_temp)
    r = np.array(r).T
    nodes = np.array(nodes).T.astype(int)
    return r, nodes


def cal_max_r(N_years, month_ind):
    N_nodes = 18048
    r, nodes = read_rvalues(N_years, month_ind)
    r_max = []; nodes_ind = []; deg = []
    for n in range(N_nodes):
        max_ind = np.argmax(np.abs(r[n,:]))
        r_temp = r[n, max_ind]
        nodes_temp = nodes[n, max_ind]
        nodes_ind.append(nodes_temp)
        r_max.append(r_temp)
        deg.append(max_ind)
    return np.array(r_max), deg, nodes_ind


def cal_firstyears_rvalue(N_years, month_ind):
    nc = Dataset(path+'prate.sfc.mon.mean.nc','r',format='NETCDF4')
    lat = nc.variables['lat'][:]; lon = nc.variables['lon'][:]
    xx, yy = np.meshgrid(lon, lat)
    x2 = xx.flatten(); y2 = yy.flatten()
    from scipy.stats.stats import pearsonr
    degree = merge_data()
    prate = read_prate(month_ind)
    r, deg, nodes = cal_max_r(N_years, month_ind)
    r2 = []
    pred_info = []
    for n in range(len(r)):
        print(n)
        k = -1
        for d in range(6):
            for w in range(8):
                k += 1
                if k == deg[n]:
                    deg_ind = d
                    weight_ind = w
        degree2 = read_deg_by_nodes(degree, nodes[n], deg_ind, weight_ind)
        degree2 = degree2[:73-N_years]
        prate2 = prate[n, :73-N_years]
        r2_temp, p2_temp = pearsonr(degree2, prate2)
        r2.append(r2_temp)
        if (r[n]>r2_temp>0 or r[n]<r2_temp<0) and p2_temp < 0.001:
            temp_info = [n, y2[n], x2[n], nodes[n], weights[weight_ind], degrees[deg_ind], r[n], r2_temp, p2_temp]
            pred_info.append(temp_info)
    return r2, np.array(pred_info)