import numpy as np
from scipy.stats.stats import pearsonr
import multiprocessing
path = '/public3/home/sc52351/ranguanghao/hainan0606/data/'

def read_prate(year_length, month_ind):
    prate = np.loadtxt(path+'ori/{}years/prate_{}.dat'.format(year_length, month_ind))
    return prate


def read_degree(year_length, deg_ind):
    degree = np.loadtxt(path+'ori/{}years/degree_{}.dat'.format(year_length, deg_ind))
    return degree


def calculation(deg_ind):
    year_length = 40; month_ind = 2
    prate = read_prate(year_length, month_ind)
    degree = read_degree(year_length, deg_ind)
    N1 = 18048; N2 = 6242
    info = []
    for n1 in range(N1):
        r_max = 0
        for n2 in range(N2):
            print(deg_ind, n1, n2)
            r_temp, p_temp = pearsonr(prate[n1,:], degree[n2,:])
            if abs(r_temp) > abs(r_max):
                r_max = r_temp
                p = p_temp
                best_node = n2
        temp = [n1, best_node, r_max, p]
        info.append(temp)
    np.savetxt(path+'results2/{}years/rvalue_deg{}_month{}.dat'.format(year_length,
                                                                       deg_ind, month_ind),
               info, '%.d %.d %.6f %.6f')
    
    
#------------------------------------------------------------------------------
processes = []
for deg_ind in range(48):
    p = multiprocessing.Process(target=calculation, args=[deg_ind+1])
    if __name__ == "__main__":
        p.start()
        processes.append(p)
for p in processes:
    p.join()