import numpy as np
from netCDF4 import Dataset
import time

def nodes_selection():
    file = './hainan_0129/air.2m.gauss.1948.nc'
    nc = Dataset(file)
    lats = nc.variables['lat'][:]
    lons = nc.variables['lon'][:]
    
    node = []; lat = []; lon = []
    resolution = 2
    for i in range(0, len(lats), resolution):
        temp = lats[i]
        a = np.cos(temp*np.pi/180)
        if a==0:
            b = 1
        else:
            b = round(1/a)
        y = np.arange(0, len(lons), b)
        for j in y:
            lat.append(temp)
            lon.append(lons[j])
            n = i*len(lons)+j
            node.append(n)
    return node
selected_nodes = nodes_selection()


def cut_leap(data):
    data = np.delete(data, 59, 0)
    return data


def read_data(year):
    filename = './hainan_0129/air.2m.gauss.{}.nc'.format(year)
    nc = Dataset(filename)
    data = nc.variables['air'][:]
    data = data.reshape(data.shape[0], data.shape[1]*data.shape[2])
    data = data[:, selected_nodes]
    if (year%4==0 and year%100!=0) or year%400==0:
        data = cut_leap(data)
    return data


def anomalies(year): # for year behind 1952
    time_unit = 365
    
    data = read_data(year)
    
    data_merge = np.zeros([0, len(selected_nodes)], dtype=float)
    for i in range(1948, year):
        temp = read_data(i)
        data_merge = np.vstack((data_merge, temp))
    
    years = np.arange(1948, year)
    year_list = []
    for y in range(len(years)):
        temp = time_unit * y
        year_list.append(temp)
        
    avg = np.zeros([time_unit, len(selected_nodes)], dtype=float)
    std = np.zeros_like(avg)
    for day in range(0, time_unit):
        temp = [k + day for k in year_list]
        avg[day,:] = np.mean(data_merge[temp,:], axis=0)
        std[day,:] = np.std(data_merge[temp,:], axis=0)
         
    data_ano = np.zeros([data.shape[0], len(selected_nodes)], dtype=float)
    for day in range(data.shape[0]):
        data_ano[day, :] = np.divide((data[day, :]-avg[day, :]), std[day, :])
    
    return data_ano


def anomalies_2(year): #for year from 1948 to 1952
    time_unit = 365
    
    data = read_data(year)
    
    data_merge = np.zeros([0, len(selected_nodes)], dtype=float)
    for i in range(1948, 1953):
        temp = read_data(i)
        data_merge = np.vstack((data_merge, temp))
    
    years = np.arange(1948, 1953)
    year_list = []
    for y in range(len(years)):
        temp = time_unit * y
        year_list.append(temp)
        
    avg = np.zeros([time_unit, len(selected_nodes)], dtype=float)
    std = np.zeros_like(avg)
    for day in range(0, time_unit):
        temp = [k + day for k in year_list]
        avg[day,:] = np.mean(data_merge[temp,:], axis=0)
        std[day,:] = np.std(data_merge[temp,:], axis=0)
         
    data_ano = np.zeros([data.shape[0], len(selected_nodes)], dtype=float)
    for day in range(data.shape[0]):
        data_ano[day, :] = np.divide((data[day, :]-avg[day, :]), std[day, :])
    
    return data_ano


def run_anomalies():
    data_all = np.zeros([0, len(selected_nodes)], dtype=float)
    total_st = time.time()
    for year in range(1948, 2022):
        if year < 1953:
            st = time.time()
            data = anomalies_2(year)
            ed = time.time()
        else:
            st = time.time()
            data = anomalies(year)
            ed = time.time()

        data_all = np.vstack((data_all, data))
        print('year {} has done: {}s'.format(year, ed-st))
    total_ed = time.time()
    print('Time cost in total: {}s'.format(total_ed-total_st))
    return data_all