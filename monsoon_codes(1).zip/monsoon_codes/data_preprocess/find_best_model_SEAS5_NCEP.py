import numpy as np
import matplotlib.pylab as plt
from netCDF4 import Dataset
path = './'

def read_prate(nodes_ind, month_ind):
    prate = np.loadtxt(path+'prate_{}.dat'.format(month_ind))
    mean_prate = np.mean(prate[nodes_ind, -33:], axis=0)
    return mean_prate


def read_forecast_data():
    file = 'ecmwf_system5_leading1.nc'
    nc = Dataset(file)
    tprate = nc.variables['tprate'][:]
    return tprate


def pick_region(llat, ulat, rlon, llon):
    file = 'ecmwf_system5_leading1.nc'
    nc = Dataset(file)
    lats = nc.variables['latitude'][:]; lons = nc.variables['longitude'][:]
    x, y = np.meshgrid(lons, lats)
    xx = x.flatten(); yy = y.flatten()
    nodes_ind = []
    for i in range(len(xx)):
        if llat < yy[i] < ulat and rlon < xx[i] < llon:
            nodes_ind.append(i)
    return nodes_ind


def cal_mean_prate_season1(llat, ulat, rlon, llon):       
    months = np.arange(396).reshape(33,-1)
    months_ind = []
    for y in range(33):
        temp = months[y][4:10]
        months_ind.append(temp)
    nodes = pick_region(llat, ulat, rlon, llon)
    tprate = read_forecast_data()
    target_tprate = np.reshape(tprate, (394,51,-1))[:,:25,nodes]
    ensembles = []
    for member in range(25): 
        mean_tprate = []
        for year in range(33):
            temp = np.mean(target_tprate[months_ind[year],member,:]) * 1000
            mean_tprate.append(temp)
        ensembles.append(mean_tprate)
    return np.array(ensembles)


def cal_mean_prate_season2(llat, ulat, rlon, llon):       
    months = np.arange(396).reshape(33,-1)
    months_ind = []
    for y in range(32):
        temp1 = months[y][10:12]
        temp2 = months[y+1][:4]
        temp = list(temp1)+list(temp2)
        months_ind.append(temp)
    nodes = pick_region(llat, ulat, rlon, llon)
    tprate = read_forecast_data()
    target_tprate = np.reshape(tprate, (394,51,-1))[:,:25,nodes]
    ensembles = []
    for member in range(25): 
        mean_tprate = []
        for year in range(32):
            temp = np.mean(target_tprate[months_ind[year],member,:]) * 1000
            mean_tprate.append(temp)
        ensembles.append(mean_tprate)
    return np.array(ensembles)


def plot_ensemble(llat, ulat, rlon, llon):
    ensembles = cal_mean_prate_season2(llat, ulat, rlon, llon)
    ensembles_mean = np.mean(ensembles, axis=0)
    plt.figure(dpi=400, figsize=(10,5))
    years = np.arange(1990, 2022)
    for i in range(ensembles.shape[0]):
        plt.plot(years, ensembles[i,:], linestyle='--', marker='o', linewidth=1, alpha=.6)
    plt.plot(years, ensembles_mean, linestyle='-', marker='o', linewidth=4, color='k')
    

def cal_r(llat, ulat, rlon, llon, target, season):
    if season == 1:     
        ensembles = cal_mean_prate_season1(llat, ulat, rlon, llon)
        observed = read_prate(target, season)
    else:
        ensembles = cal_mean_prate_season2(llat, ulat, rlon, llon)
        observed = read_prate(target, season)[:-1]
    from scipy import stats
    r = []
    for member in range(ensembles.shape[0]):    
        temp_r, temp_p = stats.pearsonr(ensembles[member], observed)
        r.append(temp_r)
    max_ensembles = ensembles[np.argmax(r)]
    return r, np.array([max_ensembles, observed]).T