import numpy as np
from netCDF4 import Dataset
file = './prate.sfc.mon.mean1.nc'
nc = Dataset(file)
data = nc.variables['prate'][24:]
data = data.reshape(data.shape[0], -1)

def months_ind(season):
    k = 0
    months = []
    for year in range(74):
        if season == 1:
            month = list(np.arange(4+k*12, 10+k*12))
            months.append(month)
        elif season == 2:
            month = list(np.arange(10+k*12, 16+k*12))
            months.append(month)
        k += 1
    return months


def cal_mean_prate(season):
    months = months_ind(season)
    months.append([898,899])
    prates = []
    for month in months:
        prate = np.mean(data[month,:], axis=0)
        prates.append(prate)
    return np.array(prates).T