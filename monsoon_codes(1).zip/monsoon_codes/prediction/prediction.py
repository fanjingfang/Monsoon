import numpy as np
import matplotlib.pylab as plt
from learn_test_forecast import read_prate, read_predictors, prediction_forecasting, run
from scipy.stats import pearsonr


def read_SEAS5_info(region):
    pred_lead1 = np.loadtxt('SEAS5_leading1_'+region+'.dat')
    pred_lead4 = np.loadtxt('SEAS5_leading4_'+region+'.dat')
    # pred_lead4 = np.zeros(32)
    return pred_lead1, pred_lead4


def read_CFSv2_info(region):
    pred_lead1 = np.loadtxt('CFSv2_leading1_'+region+'.dat')
    pred_lead4 = np.loadtxt('CFSv2_leading4_'+region+'.dat')
    return pred_lead1, pred_lead4


def draw_linear(region):
    prate = read_prate(region)[:-2]
    predictor = read_predictors(region)[:-2]
    years = np.arange(1950, 2023)
    fig, ax1 = plt.subplots(dpi=300, figsize=(14,7))
    plt.title('EAR', fontsize=40)
    # plt.title('HI', fontsize=40)
    # plt.title('SEA', fontsize=40)
    # plt.title('CI', fontsize=40)
    
    ax1.plot(years, prate, color='b', marker='s', markersize=8, alpha=.7, linewidth=2)
    ax1.set_xlabel('Year', fontsize=30)
    ax1.set_ylabel('Precipitation rate \n'+r'$(kg/m^2/s)$', color='b', fontsize=30)
    ax1.tick_params(axis='y', colors='b', labelsize=26)
    ax1.tick_params(axis='x', labelsize=26, rotation=45)
    ax1.ticklabel_format(axis='y', style='sci', scilimits=(-5,-5), useMathText=True)
    
    ax2 = ax1.twinx()
    ax2.plot(years, predictor*1, color='r', marker='o', markersize=8, alpha=.7, 
             linestyle='dashed', linewidth=2)
    ax2.set_ylabel('Predictor', color='r', fontsize=30)
    ax2.tick_params(axis='y', colors='r', labelsize=26)
    
    plt.axvline(x=1990, color='k', linestyle='-', alpha=.7, linewidth=3)
    plt.axvline(x=1999, color='g', linestyle='-', alpha=.8, linewidth=3)
    
    ax1.spines['top'].set_linewidth(0)
    ax1.spines['right'].set_linewidth(2)
    ax1.spines['bottom'].set_linewidth(2)
    ax1.spines['left'].set_linewidth(2)
    ax2.spines['top'].set_linewidth(0)
    ax2.spines['right'].set_linewidth(2)
    ax2.spines['bottom'].set_linewidth(2)
    ax2.spines['left'].set_linewidth(2)
    
    plt.rc('font', size=26)
    plt.savefig(region+'linear.svg', format='svg', bbox_inches='tight')
    # import pandas as pd
    # import seaborn as sns
    # from scipy.stats import pearsonr
    # region = 'CI'
    # fig, ax3 = plt.subplots(dpi=300, figsize=(7,7))
    # plt.title(region+'\n 1950-1989', fontsize=30)
    # r1, p1 = pearsonr(predictor[:40], prate[:40])
    # print(p1)
    # df = pd.DataFrame({'data1':predictor[:40], 'data2':prate[:40]})
    # sns.regplot(data=df, x='data1', y='data2', scatter=False,
    #             line_kws={'lw':10,'color':'k','alpha':.7})
    # ax3.scatter(predictor[:40], prate[:40], marker='o', s=300, color='r', edgecolor='k')
    # ax3.set_xlabel('Predictor', fontsize=30)
    # ax3.set_ylabel('Precipitation rate \n'+r'$(kg/m^2/s)$', fontsize=30)
    # ax3.ticklabel_format(axis='y', style='sci', scilimits=(-5,-5), useMathText=True)
    # bbox_props = dict(boxstyle="square,pad=0.3", fc="none", ec="none", lw=0.72)
    # r1_text = r'r = {:.2f}'.format(r1); p1_text = r'p < 0.05'
    # ax3.text(0.02, 0.99, r1_text+'\n'+p1_text, transform=ax3.transAxes,
    #          va="top", ha="left", fontsize=24, bbox=bbox_props)
    # plt.show()
    
    # fig, ax4 = plt.subplots(dpi=300, figsize=(7,7))
    # plt.title(region+'\n 1990-2022', fontsize=30)
    # r2, p2 = pearsonr(predictor[40:], prate[40:])
    # df = pd.DataFrame({'data1':predictor[40:], 'data2':prate[40:]})
    # sns.regplot(data=df, x='data1', y='data2', scatter=False,
    #             line_kws={'lw':10,'color':'k','alpha':.7})
    # ax4.scatter(predictor[40:], prate[40:], marker='o', s=300, color='r', edgecolor='k')
    # ax4.set_xlabel('Predictor', fontsize=30)
    # ax4.set_ylabel('Precipitation rate \n'+r'$(kg/m^2/s)$', fontsize=30)
    # ax4.ticklabel_format(axis='y', style='sci', scilimits=(-5,-5), useMathText=True)
    # bbox_props = dict(boxstyle="square,pad=0.3", fc="none", ec="none", lw=0.72)
    # r2_text = r'r = {:.2f}'.format(r2); p2_text = r'p < 0.05'
    # ax4.text(0.02, 0.99, r2_text+'\n'+p2_text, transform=ax4.transAxes,
    #          va="top", ha="left", fontsize=24, bbox=bbox_props)


def plot_prediction_SEAS5(region, obs, pred_net, pred_lead1, pred_lead4, error, testing_length, rmse, mape):
    fig1, ax = plt.subplots(dpi=400, figsize=(12,3))
    plt.title('EAR', fontsize=24)
    
    year_start = 1990 + testing_length
    x = list(np.arange(year_start, year_start+len(obs)))
    x2 = list(np.arange(year_start, year_start+len(pred_lead1)))
    plt.plot(x[:10], obs[:10], marker='o', markersize=6, linestyle='solid', 
             linewidth=1.25, color='#1e90ff')
    plt.plot(x[:10], pred_net[:10], marker='s', markersize=6, linestyle='dashed', 
             linewidth=1.25, color='g')
    plt.plot(x[10:], obs[10:], marker='o', markersize=8, linestyle='solid', 
             linewidth=2, color='#1e90ff', alpha=.8, label='Observed values')
    plt.plot(x[10:], pred_net[10:], marker='s', markersize=8, linestyle='dashed', 
             linewidth=2, color='g', alpha=.8, label='Networks Predicted values')
    
    plt.plot(x2[:10], pred_lead1[:10], marker='^', markersize=6, linestyle='dotted', 
             linewidth=1, color='#c70039', alpha=.8)
    plt.plot(x2[:10], pred_lead4[:10], marker='>', markersize=6, linestyle='dotted', 
             linewidth=1, color='k', alpha=.8)
    plt.plot(x2[10:], pred_lead1[10:], marker='^', markersize=8, linestyle='dotted', 
             linewidth=2, color='#c70039', alpha=.8, label='SEAS5 (leading 1 month)')
    plt.plot(x2[10:], pred_lead4[10:], marker='>', markersize=8, linestyle='dotted', 
             linewidth=2, color='k', alpha=.8, label='SEAS5 (leading 4 months)')
    # plt.fill_between(x, pred_net-error, pred_net+error, color='g', alpha=.2, label='95% CI')
    ylim = plt.ylim()
    ymax = ylim[1]; ymin = ylim[0]
    plt.fill_between(x, ymin, ymax, where=(np.array(x) >= 1990) & (np.array(x) <= 1999), color='k', alpha=0.1, label='Training phase')
    plt.axvline(x=1999, color='k', linestyle='--')
    # plt.legend(framealpha=.2, edgecolor='none', fontsize=16, loc='upper left', bbox_to_anchor=(-0.15, -.35), ncol=3)
    
    xx = list(np.arange(year_start, year_start+len(obs), 2))
    year = [str(i) for i in xx]
    plt.xticks(xx, year, rotation=45, fontsize=14)
    plt.yticks(fontsize=14)
    plt.xlabel('Year', fontsize=18)
    # plt.ylim(0.00007,0.00017)
    plt.ylabel('Precipitation rate \n'+r'$(kg/m^2/s)$', fontsize=18)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(-5,-5), useMathText=True)
    plt.rc('font', size=14)
    
    ax.spines['top'].set_linewidth(0)
    ax.spines['right'].set_linewidth(0)
    ax.spines['bottom'].set_linewidth(2.5)
    ax.spines['left'].set_linewidth(2.5)
    # plt.savefig(region+'1.svg', format='svg', bbox_inches='tight')
    # plt.show()
    
    import seaborn as sns
    import pandas as pd
    from scipy import stats
    from matplotlib.ticker import MaxNLocator
    
    # year_list = np.arange(year_start, 2023)
    r, p = stats.pearsonr(obs[10:], pred_net[10:])
    fig2, ax = plt.subplots(dpi=400, figsize=(5,5))
    print(p)
    # plt.title(r'$r={:.2f}$'.format(r)+' **', fontsize=20)
    plt.title('CI', fontsize=20)
    xx = np.linspace(np.min(obs), np.max(obs), 100); yy = xx
    # ax.plot(xx, yy, linestyle='dashed', color='k', linewidth=5, alpha=.8, label='1:1 line') # 1:1 line
    # ax.scatter(pred_net[:10], obs[:10], marker='o', edgecolors='k', c='b', s=200, alpha=.7, label='')
    ax.scatter(pred_net[10:], obs[10:], marker='s', edgecolors='k', c='g', s=150, alpha=.7, label='')
    # ax.scatter(pred_lead1[10:], obs[10:], marker='^', edgecolors='k', c='#c70039', s=100, alpha=.7, label='')
    # ax.scatter(pred_lead4[10:], obs[10:], marker='>', edgecolors='k', c='k', s=100, alpha=.7, label='')
    
    rmse_text = r'RMSE: {:.2f}$\times 10^{{-5}}$ kg/$m^2$/s'.format(rmse*100000)
    mape_text = r'MAPE: {:.2f}%'.format(mape*100)
    r_text = r'r: {:.2f}'.format(r)
    bbox_props = dict(boxstyle="square,pad=0.3", fc="none", ec="none", lw=0.72)
    ax.text(0.02, 0.99, r_text+'\n'+mape_text+'\n'+rmse_text, transform=ax.transAxes,
            va="top", ha="left", fontsize=14, bbox=bbox_props)
    
    locator=MaxNLocator(prune='both', nbins=10)
    ax.xaxis.set_major_locator(locator)
    ax.yaxis.set_major_locator(locator)
    
    df = pd.DataFrame({'data1':obs[10:], 'data2':pred_net[10:]})
    sns.regplot(data=df, x='data2', y='data1', scatter=False,
                line_kws={'lw':10,'color':'k','alpha':.7},
                ci=99, label='Regression')
    # plt.legend(fontsize=18, framealpha=.2, edgecolor='k', loc='upper left')
    # plt.legend(fontsize=18, framealpha=.2, edgecolor='k', loc='lower right')
    # pred = [pred_net[:], pred_lead1, pred_lead4]
    pred = pred_net
    vmin = min(np.min(obs), np.min(pred)) * 0.95
    vmax = max(np.max(obs), np.max(pred)) * 1.05
    
    plt.xlabel('Predicted', fontsize=24)
    plt.xlim(vmin, vmax)
    plt.ylabel('Observed', fontsize=24)
    plt.ylim(vmin, vmax)
    # plt.grid(True)
    # plt.text(min(xx), max(yy)*.8, '\n'+r'$r={:.2f}$'.format(r)+'\n'+r'$p=0.000*$', fontsize=14)
    
    # plt.locator_params(axis='x', nbins=3)
    # plt.locator_params(axis='y', nbins=3)
    
    plt.tick_params(axis='both', labelsize=16)
    locator=MaxNLocator(prune='both', nbins=6)
    ax.xaxis.set_major_locator(locator)
    ax.yaxis.set_major_locator(locator)
    plt.ticklabel_format(axis='both', style='sci', scilimits=(-5,-5), useMathText=True)
    plt.rc('font', size=16)
    
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    
    plt.savefig(region+'2_SL.svg', format='svg', bbox_inches='tight')
    return fig1, fig2
    
    
def plot_prediction_CFS(region, obs, pred_net, pred_lead1, pred_lead4, error, testing_length):
    fig, ax = plt.subplots(dpi=300, figsize=(12,3))
    plt.title('CI', fontsize=22)
    
    year_start = 1990 + testing_length
    x = list(np.arange(year_start, year_start+len(obs)))
    x2 = list(np.arange(year_start+3, year_start+3+len(pred_lead1)))
    plt.plot(x, obs, marker='o', markersize=6, linestyle='solid', linewidth=2, 
             color='#1e90ff', label='Observed values')
    plt.plot(x, pred_net, marker='s', markersize=6, linestyle='dashed', linewidth=2, 
             color='g', alpha=.8, label='Networks Predicted values')
    plt.plot(x2, pred_lead1, marker='^', markersize=6, linestyle='dotted', linewidth=1, 
             color='#c70039', alpha=.8, label='CFSv2 (leading 1 month)')
    plt.plot(x2, pred_lead4, marker='>', markersize=6, linestyle='dotted', linewidth=1, 
             color='k', alpha=.8, label='CFSv2 (leading 4 months)')
    # plt.fill_between(x, pred_net-error, pred_net+error, color='g', alpha=.2, label='95% CI')
    ylim = plt.ylim()
    ymax = ylim[1]; ymin = ylim[0]
    plt.fill_between(x, ymin, ymax, where=(np.array(x) >= 1990) & (np.array(x) <= 1999), 
                     color='k', alpha=0.1, label='Training phase')
    plt.axvline(x=1999, color='k', linestyle='--')
    plt.legend(framealpha=.2, edgecolor='none', fontsize=16, loc='upper left', 
               bbox_to_anchor=(-0.1, -.35), ncol=3)
    
    xx = list(np.arange(year_start, year_start+len(obs), 2))
    year = [str(i) for i in xx]
    plt.xticks(xx, year, rotation=45, fontsize=14)
    plt.yticks(fontsize=14)
    plt.xlabel('Year', fontsize=20)
    # plt.ylim(0.00007,0.00017)
    plt.ylabel('Precipitation rate \n'+r'$(Kg/m^2/s)$', fontsize=20)
    plt.ticklabel_format(axis='y', style='sci', scilimits=(-5,-5), useMathText=True)
    plt.rc('font', size=14)
    
    ax.spines['top'].set_linewidth(0)
    ax.spines['right'].set_linewidth(0)
    ax.spines['bottom'].set_linewidth(2.5)
    ax.spines['left'].set_linewidth(2.5)
    plt.show()
    
    import seaborn as sns
    import pandas as pd
    from scipy import stats
    from matplotlib.ticker import MaxNLocator
    
    # year_list = np.arange(year_start, 2023)
    r, p = stats.pearsonr(obs[10:], pred_net[10:])
    fig, ax = plt.subplots(dpi=300, figsize=(5,5))
    plt.title(r'$r={:.2f}$'.format(r), fontsize=20)
    xx = np.linspace(np.min(obs), np.max(obs), 100); yy = xx
    ax.plot(xx, yy, linestyle='dashed', color='k', linewidth=5, alpha=.8, label='1:1 line') # 1:1 line
    # ax.scatter(pred_net[:10], obs[:10], marker='o', edgecolors='k', c='b', s=150, alpha=.7, label='')
    ax.scatter(pred_net[10:], obs[10:], marker='o', edgecolors='k', c='r', s=150, alpha=.7, label='')
    
    # locator=MaxNLocator(prune='both', nbins=3)
    # ax.xaxis.set_major_locator(locator)
    # ax.yaxis.set_major_locator(locator)
    
    df = pd.DataFrame({'data1':obs[10:], 'data2':pred_net[10:]})
    sns.regplot(data=df, x='data2', y='data1', scatter=False,
                line_kws={'lw':10,'color':'r','alpha':.7},
                ci=99, label='regression line')
    # plt.legend(fontsize=14, framealpha=.2, edgecolor='k', loc='upper left')
    plt.legend(fontsize=14, framealpha=.2, edgecolor='k', loc='lower right')
    
    vmin = min(np.min(obs), np.min(pred_net)) * .95
    vmax = max(np.max(obs), np.max(pred_net)) * 1.05
    
    plt.xlabel('Predicted', fontsize=24)
    plt.xlim(vmin, vmax)
    plt.ylabel('Observed', fontsize=24)
    plt.ylim(vmin, vmax)
    # plt.text(min(xx), max(yy)*.8, '\n'+r'$r={:.2f}$'.format(r)+'\n'+r'$p=0.000*$', fontsize=14)
    
    # plt.locator_params(axis='x', nbins=3)
    # plt.locator_params(axis='y', nbins=3)
    
    plt.tick_params(axis='both', labelsize=16)
    locator=MaxNLocator(prune='both', nbins=5)
    ax.xaxis.set_major_locator(locator)
    ax.yaxis.set_major_locator(locator)
    plt.ticklabel_format(axis='both', style='sci', scilimits=(-5,-5), useMathText=True)
    plt.rc('font', size=16)
    
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)


def cal_errors(pred, obs):
    MAPE = np.mean(np.divide(np.abs(pred-obs),obs))
    RMSE = np.sqrt(np.mean((pred-obs)**2))
    return MAPE, RMSE

    
def run_draw_SEAS5(region, testing_length, optimal_L):
    prate = read_prate(region)
    predictor = read_predictors(region)
    # print(predictor)
    # print(len(predictor))
    pred_net = []; error = []
    for i in range(3):
        pred_temp, obs, error_temp = prediction_forecasting(predictor, prate, testing_length, optimal_L[i])
        pred_net.append(pred_temp); error.append(error_temp[:,0])
    pred_net = np.mean(np.array(pred_net), axis=0)
    error = np.mean(np.array(error), axis=0)
    pred_lead1, pred_lead4 = read_SEAS5_info(region)
    pred_lead1 = pred_lead1[testing_length:]
    pred_lead4 = pred_lead4[testing_length:]
    # print(len(pred_lead1), len(obs))
    # r_lead1, _ = pearsonr(pred_lead1[10:], obs[10:-2])
    # r_lead4, _ = pearsonr(pred_lead4[10:], obs[10:-2])
    # print(r_lead1, r_lead4)
    mape, rmse = cal_errors(pred_net[10:], obs[10:])
    # mape1, rmse1 = cal_errors(pred_lead4[10:], obs[10:]); r1, _ = pearsonr(pred_lead4[10:], obs[10:])
    # print(region)
    # print(mape, rmse)
    # print(mape1, rmse1, r1)
    
    plot_prediction_SEAS5(region, obs, pred_net, pred_lead1, pred_lead4, error, testing_length, rmse, mape)
    return pred_net, obs, pred_lead1, pred_lead4, error


def run_draw_CFS(region, testing_length, optimal_L):
    prate = read_prate(region)
    predictor = read_predictors(region)
    pred_net = []; error = []
    for i in range(3):
        pred_temp, obs, error_temp = prediction_forecasting(predictor, prate, testing_length, optimal_L[i])
        pred_net.append(pred_temp); error.append(error_temp[:,0])
    pred_net = np.mean(np.array(pred_net), axis=0)
    error = np.mean(np.array(error), axis=0)
    pred_lead1, pred_lead4 = read_CFSv2_info(region)
    pred_lead1 = pred_lead1[testing_length:]
    pred_lead4 = pred_lead4[testing_length:]
    print(len(pred_lead1), len(obs))
    # r_lead1, _ = pearsonr(pred_lead1[7:], obs[10:-8])
    # r_lead4, _ = pearsonr(pred_lead4[7:], obs[10:-8])
    # print(r_lead1, r_lead4)
    mape, rmse = cal_errors(pred_net[10:-8], obs[10:-8]); r, _ = pearsonr(pred_net[10:-8], obs[10:-8])
    mape1, rmse1 = cal_errors(pred_lead1[7:], obs[10:-8]); r1, _ = pearsonr(pred_lead1[7:], obs[10:-8])
    mape2, rmse2 = cal_errors(pred_lead4[7:], obs[10:-8]); r2, _ = pearsonr(pred_lead4[7:], obs[10:-8])
    # print(region)
    print(mape, rmse, r)
    print(mape1, rmse1, r1)
    print(mape2, rmse2, r2)
    # 
    plot_prediction_CFS(region, obs, pred_net, pred_lead1, pred_lead4, error, testing_length)
    return pred_net, obs, pred_lead1, pred_lead4, error