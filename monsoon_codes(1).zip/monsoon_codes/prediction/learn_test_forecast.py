import numpy as np
import statsmodels.api as sm
from scipy.stats import pearsonr
import matplotlib.pylab as plt

def read_predictors(region):
    filename = 'predictor_'+region+'.dat'
    data = np.loadtxt(filename)
    return data


def read_prate(region):
    data = np.loadtxt('prate_'+region+'.dat')
    return data


def regression(data1, data2, start, end): # provide the CI on the basis of regression
    x1 = data1[start:end]
    x = np.array([x1]).T
    y = data2[start:end]
    model = sm.OLS(y, sm.add_constant(x))
    result = model.fit()
    params = result.params
    const = params[0]; coef_x1 = params[1]
    z1 = data1[end]
    predict = coef_x1*z1 + const
    
    Z_with_constant = [1, z1]
    confidence_interval = result.get_prediction(Z_with_constant).conf_int(alpha=.1)
    error = predict - confidence_interval[0]
    
    return predict, error
    
    
def prediction_testing(predictor, prate, testing_length):
    testing_phase_start = 40
    testing_phase_end = testing_phase_start + testing_length
    learning_length = np.arange(5, 41)
    data1 = predictor[:testing_phase_end]
    data2 = prate[:testing_phase_end]
    obs = prate[testing_phase_start:testing_phase_end]
    pred = []
    for L in learning_length:
        pred_L = []
        for testing in range(testing_phase_start, testing_phase_end):
            start = testing - L
            end = testing
            pred_temp, _ = regression(data1, data2, start, end)
            pred_L.append(pred_temp)
        pred.append(pred_L)
    return np.array(pred).T, obs


def prediction_forecasting(predictor, prate, testing_length, optimal_L):
    forecasting_phase_start = 40 + testing_length
    forecasting_phase_end = 73
    data1 = predictor
    data2 = prate
    obs = prate[forecasting_phase_start:forecasting_phase_end]
    pred = []; error = []
    for forecasting in range(forecasting_phase_start, forecasting_phase_end):
        start = forecasting - optimal_L
        end = forecasting
        pred_temp, error_temp = regression(data1, data2, start, end)
        pred.append(pred_temp); error.append(error_temp)
    return np.array(pred), np.array(obs), np.array(error)


def cal_mape_rmse(pred, obs):
    mape = []; rmse = []; r = []
    for i in range(pred.shape[1]): # where shape[1] contains different results within learning_lengths
        mape_temp = np.mean(abs(np.array(pred[:,i])-np.array(obs))/np.array(obs))
        rmse_temp = np.sqrt(np.mean((np.array(pred[:,i])-np.array(obs))**2))
        r_temp, _ = pearsonr(pred[:,i], obs)
        # print(pred[:,i])
        mape.append(mape_temp); rmse.append(rmse_temp); r.append(r_temp)
    return mape, rmse, r


def normalize2(data):
    vmax = np.amax(data)
    data = data/vmax
    return data


#------------------------------------------------------------------------------
def run(region):
    predictor = read_predictors(region)
    prate = read_prate(region)
    learning_lengths = np.arange(5, 41)
    testing_lengths = [10]
    for testing_length in testing_lengths:
        pred_test, obs_test = prediction_testing(predictor, prate, testing_length)
        mape_test, rmse_test, r_test = cal_mape_rmse(pred_test, obs_test)
    
    fig, ax1 = plt.subplots(dpi=300, figsize=(10,5))
    # plt.title('EAR', fontsize=26)
    # plt.title('HI', fontsize=26)
    # plt.title('SEA', fontsize=26)
    plt.title('CI', fontsize=26)
    ax1.plot(learning_lengths, normalize2(mape_test), c='#0094ff', marker='>', 
             linestyle='dashed', linewidth=1, label=r'$MAPE_{norm}$')
    ax1.plot(learning_lengths, normalize2(rmse_test), c='#008d00', marker='^', 
             linestyle='dashed', linewidth=1, label=r'$RMSE_{norm}$')
    ax1.plot(learning_lengths, normalize2(np.abs(r_test)), c='#ff9200', marker='<', 
             linestyle='dashed', linewidth=1, label=r'$|PCC|_{norm}$')
    ax1.set_xlabel('Learning length: '+r'$L$'+'(years)', fontsize=20)
    ax1.tick_params(axis='y', colors='k', labelsize=18)
    ax1.tick_params(axis='x', labelsize=18)
    ax1.spines['top'].set_linewidth(0)
    ax1.spines['right'].set_linewidth(2)
    ax1.spines['bottom'].set_linewidth(2.5)
    ax1.spines['left'].set_linewidth(2)
    ax2 = ax1.twinx()
    
    # criteria = np.array(np.abs(r_test))*(1/np.array(normalize2(mape_test)))*(1/np.array(normalize2(rmse_test)))
    criteria = np.array(normalize2(np.abs(r_test)))*(1/np.array(mape_test))*(1/np.array(rmse_test))
    # criteria = 1/3 * (np.array(normalize(np.abs(r_test))) + (1 - np.array(normalize2(mape_test))) + (1 - np.array(normalize2(rmse_test))))
    
    optimal_L = learning_lengths[np.argmax(criteria)]
    print(optimal_L, criteria[optimal_L-5])
    ax2.plot(learning_lengths, np.log10(criteria), c='#e5086a', marker='o', linestyle='solid', linewidth=2.5,
             label=r'$\log_{10}\lambda$')
    ax2.axvline(x=optimal_L, color='#e5086a', linestyle='--', linewidth=1.5)
    ax2.text(optimal_L-.5, np.min(np.log10(criteria))+0.05, f'L={optimal_L}', va='top', ha='right', fontsize=26)
    ax2.tick_params(axis='y', colors='k', labelsize=18)
    ax2.spines['top'].set_linewidth(0)
    ax2.spines['right'].set_linewidth(2)
    ax2.spines['bottom'].set_linewidth(2.5)
    ax2.spines['left'].set_linewidth(2)
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    lines = lines1 + lines2; labels = labels1 + labels2
    ax1.legend(lines, labels, loc='upper left', bbox_to_anchor=(-.1, -0.2), ncol=4, fontsize=18)
    # return Ls, weights
    return np.array([mape_test, rmse_test, r_test, criteria])